-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 30 2020 г., 18:30
-- Версия сервера: 10.3.13-MariaDB-log
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `thebestwatchstore`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `order_id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `item_id` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `price` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `fio` varchar(30) NOT NULL,
  `text` text NOT NULL,
  `time_create` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `short_descr` text NOT NULL,
  `description` text NOT NULL,
  `image_name` varchar(10) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `title`, `short_descr`, `description`, `image_name`, `price`) VALUES
(1, 'Наручные часы TAG Heuer', 'Механические, мужские, аналоговые, корпус из стали, браслет: кожа, водонепроницаемость: WR100 (плавание, ныряние без акваланга)', 'Тип механические с автоподзаводом. Пол мужские. Механизм Tag Heuer 16. Способ отображения времени аналоговый (стрелки), формат 12 часов, секундная стрелка смещенная. Цифры арабские. Источник энергии пружинный механизм. Водонепроницаемые да. Класс водонепроницаемости WR100 (плавание, ныряние без акваланга). Материал корпуса нерж. сталь. Материал браслета/ремешка кожа (аллигатор). Стекло сапфировое, с антибликовым покрытием. Диаметр корпуса 43 мм. Хронограф есть. Запас хода 42 ч. Отображение даты число, день недели. Спорт-функции секундомер. Подсветка стрелок. Страна производства Швейцария.\r\n\r\n\r\n', '1', 292000),
(2, 'Наручные часы Maurice Lacroix', 'механические, мужские, аналоговые, корпус из стали, браслет: кожа, число камней: 25, водонепроницаемость: WR100 (плавание, ныряние без акваланга)', 'Тип механические с автоподзаводом. Пол мужские. Способ отображения времени аналоговый (стрелки), формат 12 часов, секундная стрелка смещенная. Цифры отсутствуют. Источник энергии пружинный механизм. Водонепроницаемые да. Класс водонепроницаемости WR100 (плавание, ныряние без акваланга). Материал корпуса нерж. сталь. Материал браслета/ремешка кожа. Количество камней 25. Стекло сапфировое, с антибликовым покрытием. Диаметр корпуса 43 мм\r\n\r\n', '2', 188300),
(3, 'Наручные часы VICTORINOX', 'механические, мужские, аналоговые, корпус из стали, браслет: нерж. сталь, водонепроницаемость: WR100 (плавание, ныряние без акваланга)\r\n', 'Тип механические с автоподзаводом\r\nПол мужские\r\nМеханизм ETA Valjoux 7750\r\nСпособ отображения времени аналоговый (стрелки), формат 12 часов, секундная стрелка смещенная\r\nЦифры арабские\r\nИсточник энергии пружинный механизм\r\nВодонепроницаемые да\r\nКласс водонепроницаемости WR100 (плавание, ныряние без акваланга)\r\nМатериал корпуса нерж. сталь, PVD покрытие (полное)\r\nМатериал браслета/ремешка нерж. сталь, PVD покрытие (полное)\r\nСтекло сапфировое, с антибликовым покрытием\r\nДиаметр корпуса 42 мм\r\nХронограф есть\r\nОтображение даты число\r\nСпорт-функции секундомер\r\nПодсветка стрелок\r\nСтрана производства Швейцария\r\n', '3', 105000);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`order_id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
